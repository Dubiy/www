#SXD20|20010|50140|50313|2014.12.14 09:56:27|deti|0|6|26|
#TA answers`9`788|likes`9`340|questions`4`380|tag_usages`0`0|tags`0`0|users`4`196
#EOH

#	TC`answers`utf8_general_ci	;
CREATE TABLE `answers` (
  `answer_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `question_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `text` text,
  `rating` int(11) DEFAULT '0',
  `datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`answer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8	;
#	TD`answers`utf8_general_ci	;
INSERT INTO `answers` VALUES 
(1,1,1,'Тінкі-вінкі - the best!!!',10,'2014-05-10 00:00:00'),
(2,2,1,'хахаха',-11,'2014-06-15 00:00:00'),
(3,2,2,'Пий кашу',54,'2014-12-12 00:00:00'),
(4,1,1,'qqqq',0,'2014-12-14 03:53:08'),
(5,1,1,'sdfdfdsfsdfsd',0,'2014-12-14 03:53:50'),
(6,4,1,'Ктулху фхтагн',-1,'2014-12-14 04:39:56'),
(7,4,1,'Ктулху фхтагн',1,'2014-12-14 04:42:31'),
(8,2,1,'dfhdfhfd',1,'2014-12-14 06:46:12'),
(9,1,1,'fffffffffffffffffff',1,'2014-12-14 08:24:18')	;
#	TC`likes`utf8_general_ci	;
CREATE TABLE `likes` (
  `like_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `table_name` varchar(45) DEFAULT NULL,
  `table_id` int(11) DEFAULT NULL,
  `datetime` datetime DEFAULT NULL,
  `type` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`like_id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8	;
#	TD`likes`utf8_general_ci	;
INSERT INTO `likes` VALUES 
(14,1,'answers',3,'2014-12-14 05:38:39',-1),
(13,1,'questions',4,'2014-12-14 05:34:48',-1),
(12,1,'questions',2,'2014-12-14 05:31:40',1),
(11,1,'questions',3,'2014-12-14 05:31:35',1),
(15,1,'answers',2,'2014-12-14 05:38:48',-1),
(16,1,'answers',6,'2014-12-14 05:40:58',-1),
(17,1,'answers',7,'2014-12-14 05:40:59',1),
(18,1,'answers',8,'2014-12-14 06:46:16',1),
(19,1,'answers',9,'2014-12-14 08:24:35',1)	;
#	TC`questions`utf8_general_ci	;
CREATE TABLE `questions` (
  `question_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `text` text,
  `rating` int(11) DEFAULT '0',
  `datetime` datetime DEFAULT NULL,
  `psych` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0' COMMENT '0 - deti. 1 - vzrosli',
  `best` int(11) DEFAULT '0',
  PRIMARY KEY (`question_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8	;
#	TD`questions`utf8_general_ci	;
INSERT INTO `questions` VALUES 
(1,1,'Я дивлюсь телепузиків :(',3,'2014-05-12 00:00:00',0,0,0),
(2,2,'У мене випали зуби... АХАХАХ',-3,'2014-08-18 00:00:00',0,0,0),
(3,1,'Мені подобається барбі.',13,'2014-12-13 00:00:00',0,0,0),
(4,1,'Как разбудить Ктулху?',2,'2014-12-14 04:30:29',1,1,0)	;
#	TC`tag_usages`utf8_general_ci	;
CREATE TABLE `tag_usages` (
  `tag_usage_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tag_id` int(11) DEFAULT NULL,
  `question_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_usage_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`tags`utf8_general_ci	;
CREATE TABLE `tags` (
  `tag_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`users`utf8_general_ci	;
CREATE TABLE `users` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `age` int(11) DEFAULT '10',
  `sex` int(11) DEFAULT '1',
  `account_type` int(11) DEFAULT '0',
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8	;
#	TD`users`utf8_general_ci	;
INSERT INTO `users` VALUES 
(1,'netzver@gmail.com','pass123',25,1,10),
(2,'kinder@google.com','12345678',14,2,0),
(3,'ki22nder@google.com','3242354325353',14,2,0),
(4,'ahahah@gmail.com','34793846736948746',10,1,0)	;
